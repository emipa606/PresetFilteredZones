# Preset Filtered Zones

Adds six new stockpile zones which are already filtered for storing Meals, Meat, Vegetables, Medicine, Joy, or Animals. Freezer creation is a breeze!

![Preview](https://github.com/cuproPanda/FZN/blob/master/About/Preview.png?raw=true)
